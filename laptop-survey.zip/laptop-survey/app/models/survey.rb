class Survey < ApplicationRecord
end
